import random  #imports needed things (idk what to call them)
import time


def rockPaperScissors():          #a function containing the entire game is created, it is called from the bottom of the script.
    start = str(input('would you like to start?(yes / no)'))  #asks the user if they would like to start playing

    if start == 'yes':     #if user responds yes the code waits 1 second and then continues
        time.sleep(1)
    elif(start == 'no'):   #if user responds no the program quits
        exit()
    else:
        print('invalid input')
        exit()

    choice = str(input('rock paper or scissors.(input r, p or s)'))  #the program asks the user which move
                                                                    #they want to play
    computerC = random.randint(1,3)    #the computer chooses a random number(these will later be assigned to different moves

    if choice == 'r':      #the players choice also gets assigned a number
        j = 1
    elif choice == 'p':
        j = 2
    elif choice == 's':
        j = 3
    else:
        print('invalid input')
        exit()
    if (computerC==2) and (j==1):                     #all cases of possible outcomes in rock paper scissors including ties are expressed.
        print('you lost! the computer chose paper.')

    if (computerC==1) and (j==2):
        print('you won! the computer chose rock!')

    if (computerC==3) and (j==2):
        print('you lost! the computer chose scissors.')

    if (computerC==2) and (j==3):
        print('you won! the computer chose paper!')

    if (computerC==1) and (j==3):
        print('you lose! the computer chose rock')

    if (computerC==3) and (j==1):
        print('you win! the computer chose scissors!')

    if computerC==j:
        print('Tie!')

    again = str(input('Would you like to play again? (yes/no)'))

    if again == 'yes':         #the player is asked if they would like to play again.
        rockPaperScissors()    #if they respond yes, the game function is called again.
    elif again == 'no':
        exit()
    else:
        print('invalid input')
        exit()

rockPaperScissors()    #everying above is just defined, not executed, this last line actually starts the game.












